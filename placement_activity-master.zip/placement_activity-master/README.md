#Run project command is

npm run dev:frontend                                                         

#credentials

Student:
Email: student@example.com
Password: student123
Placement Officer:
Email: placement@example.com
Password: officer123
